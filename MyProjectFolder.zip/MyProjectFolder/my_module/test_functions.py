"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

import string
import random

from functions import my_func, my_other_func, find_max_att, att_connect
##
##

def test_my_func():

    assert my_func() == None

def test_my_other_func():

    assert my_other_func() == None

def test_find_max_att():
    
    assert callable(find_max_att)
    assert isinstance(find_max_att({'max':47, 'alex':57, 'angel':36}), str)
    assert find_max_att({'lisa': 78, 'alex': 65, 'suzie': 70}) == 'lisa'
    assert find_max_att({'45': 5, '80': 15, '70': 10}) == '80'
    assert find_max_att({}) == ''    


def att_connect():
    
    assert callable(att_connect)
    assert isinstance(att_connect(['whipped'], ['whipped', 'cream'], ['sour', 'candy']), str)
    assert att_connect(['angel'], ['angel', 'dust'], ['sour', 'candy']) == 'sour'
    assert isinstance(att_connect([3], [3, 4], [5, 6]), int)
    assert att_connect([6], [5, 6], [7, 8]) == 8