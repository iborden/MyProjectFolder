"""A collection of function for doing my project."""

def my_func():
    pass

def my_other_func():
    pass

import string
import random

#Categories for certain attributes of the heroes
hero_strength= {
    'Iron Man': 80,
    'Captain America': 87,
    'Black Widow': 78,
    'Thor': 95,
    'Hulk': 99,
    'Hawkeye': 75 
}

hero_speed= {
    'Iron Man': 90,
    'Captain America': 80,
    'Black Widow': 75,
    'Thor': 94,
    'Hulk': 90,
    'Hawkeye': 70
}

hero_agility= {
    'Iron Man': 82,
    'Captain America': 90,
    'Black Widow': 86,
    'Thor': 82,
    'Hulk': 70,
    'Hawkeye': 80
}

hero_intelligence= {
    'Iron Man': 99,
    'Captain America': 70,
    'Black Widow': 71,
    'Thor': 69,
    'Hulk': 95,
    'Hawkeye': 73
}

infinity_stones= {
    'Space Stone': 'A blue stone with controls over space',
    'Mind Stone': 'A yellow stone  with control over the mind/ Used by Vision',
    'Reality Stone': 'A red stone with control over reality and existence / Also known as Aether',
    'Power Stone': 'A purple stone with control over energy',
    'Time Stone': 'A green stone with control over time / Protected by Doctor Strange',
    'Soul Stone': 'An orange stone with control over life and death'
}


def find_max_att(dictionary_skills):
    """Finds the highest value and returns key associated with that value.
    
    Parameters
    ----------
    dictionary_skills : dictionary
        Dictionary containing keys and values.
    
    Returns
    -------
    final_answer : string
        String that represents key associated with highest value.
    """
    
    # Creates a list of the max values of hero strength
    list_of_values = list(dictionary_skills.values())
    
    point_max = 0
    final_answer = ''

    # Because of different values, we will use a loop go over each value
    for attributes in list_of_values:
        
        if attributes > point_max:
            point_max = attributes

    # Because the key values differ, we will loop over the keys to find correct association
    for my_hero in dictionary_skills:
        
        if dictionary_skills[my_hero] == point_max:
            final_answer = my_hero
            
    return (final_answer)


def report_all_att(dictionary_skills):
    """States all the keys:value pairs in a dictionary.
    
    Parameter
    ---------
    dictionary_skills : dictionary
        Dictionary to provide the key:value pairs
    
    Returns
    -------
    Print() : string
        Strings containing the key : value pairs"""
    
    # Because the key : value pairs differ, we will loop over each key : valuepair to gather correct info
    for instances in dictionary_skills:
        print(instances, ':', dictionary_skills[instances])


def att_connect(user_input, check_list, return_list):
    """Associates keyword with proper dictionary to produce correct function.
    
    Parameter
    ---------
    user_input : string
        String contains keywords provided by user
    
    check_list: list
        Lists contains main keywords that are cross checked with user input
    
    return_list: list
        Lists contains functions that correspond to user input
    
    Returns
    -------
    output : string
        Strings contains proper response to user input
    """
    
    output = None
    
    # Because initial keywords can differ, we will loop through user_input to find proper keyword
    for keyword in user_input:
        
        if keyword == check_list[0]:
            output = return_list[0]
        elif keyword == check_list[1]:
            output = return_list[1]
        elif keyword == check_list[2]:
            output = return_list[2]
        elif keyword == check_list[3]:
            output = return_list[3]
            
    return output


def is_question(user_input):
    """From Assignment #2. Identifys if string provided by user is a question.
    
    Parameter
    ---------
    user_input : string
        String that may contain a question mark
    
    Returns
    -------
    output : boolean
        Boolean conatining True or False"""
    
    # Checks if string contains a specific punctuation
    if '?' in user_input:
        output = True
    else:
        output = False
        
    return output


def remove_punctuation(input_string):
    """from Assignment #2. Identifys punctuation in a string and removes them.
    
    Parameter
    ---------
    input_string : string
        String that contains punctuation
    
    Returns
    -------
    out_string : string
        String containing no punctuation
    """
    
    out_string = ''
     
    for letters in input_string:
        
        # Checks if any characters are string punctuations
        if letters not in string.punctuation:
            out_string = out_string + letters
    
    return out_string


def prepare_text(input_string):
    """From Assignment #2. Converts a string of words into a list.
    
    Parameter
    ---------
    input_string : string
        String to conver to into list
    
    Returns
    -------
    out_list : list
        List containg the words from input_string"""
    
    # Converts all the characters in a string to lower case
    temp_string = input_string.lower()
    
    # Removes all the punctuation from the string
    temp_string2 = remove_punctuation(temp_string)
    
    # Splits the words from the strings into a list
    out_list = temp_string2.split()
    
    return out_list


def chat_response(user_input, check_list, return_list):
    """From Assignment #2. General response function for the chat.
    
    Parameters
    ----------
    user_input : string
        String that contains keyword provided by user
    
    check_list: list
        Lists containing main keywords that are cross checked with user input
    
    return_list: list
        Lists contains string responses that correspond to user input
    
    Returns
    -------
    output : string
        String containing proper response to user input
    """
    
    output = None
    
    # Looping through characters in a string, to recognize specific keyword used 
    for elements in user_input:
        
        if elements in check_list:
            
            # Will return a random string from the list
            output = random.choice(return_list)
    
    return output


def special_chat(user_input, check_list, return_list):
    """Derived by function from Assignment #2. Function that returns one specific response.
    
    Parameters
    ----------
    user_input : string
        String that contains keyword provided by user
    
    check_list: list
        Lists containing main keywords that are cross checked with user input
    
    return_list: list
        List containing a specific string response
    
    Returns
    -------
    output : string
        String containing proper response to user input
    """
    
    output = None
    
    # Looping through characters in a string, to recognize specific keyword used
    for specials in user_input:
        
        if specials in check_list:
            output = return_list
    
    return output


def end_chat(user_input):
    """From Assignment #2. Chat function that ends the chat
    
    Parameter
    ---------
    user_input : string
        String containg specific keyword to end the chat
    
    Returns
    -------
    boolean
        Corresponds to if correct keyword is used
    """
    
    # Checks for specific keyword, returns a boolean
    if 'inevitable' in user_input:
        return True
    else:
        return False


# Collection of input and output list that our chatbot can say and respond to
greetings_in= ['hello', 'hi', 'hey', 'sup', 'yo']
greetings_out= ['Welcome to the Avengers Index!',
                'Welcome, how can we be of assisstance?',
                'Glad you can make it! Lets talk!']

attribute_in= ['strongest', 'smartest', 'fastest', 'agile']
attribute_out= [find_max_att(hero_strength),
                find_max_att(hero_intelligence),
                find_max_att(hero_speed),
                find_max_att(hero_agility)]

iron_man_quote_in= ['iron']
iron_man_quote_out= ["'I am Iron Man'", "'I love you 3000'",
                     "'We have a Hulk'", "'I am Tony Stark'"]

hulk_quote_in= ['hulk']
hulk_quote_out= ["'HULK OUT!'", "'Puny God...'",
                 "'SO MANY STAIRS!'", "'I am Bruce Banner'"]

captain_america_quote_in= ['captain', 'america']
captain_america_quote_out= ["'I am Steve Rogers'", "'I can do this all day...'",
                            "'Avengers...assemble'"]

black_widow_quote_in= ['black', 'widow']
black_widow_quote_out= ["'He died of natural causes...gravity is natural'",
                        "'Sun is getting low...'", "'I am Natasha Romanov'"]

thor_quote_in= ['thor']
thor_quote_out= ["'I am Thor Odinson'", "'BRING ME THANOS!'",
                 "'I like this one...haha'"]

hawkeye_quote_in= ['hawkeye', 'ronin']
hawkeye_quote_out= ["'I knew I should have stretched'",
                    "'I am Clint Barton'",
                    "'I see better from a distance'"]

extra_heroes_in= ['spider', 'strange', 'marvel', 'machine', 'ant', 'scarlett', 'witch',
                  'quicksilver', 'vision', 'black', 'panther', 'quardians', 'thanos',
                  'loki', 'nick', 'fury', 'winter', 'soldier']
extra_heroes_out= 'Will be added in next update!'

restrict_in= ['dc', 'dceu', 'darkseid', 'superman', 'batman', 'wonder',
              'green', 'lantern', 'cyborg', 'flash']
restrict_out= ["We don't do that here", "Nick Fury wouldn't approve", "LANGUAGE!"]

unknown= ['That is not in out database!', 'Try asking a Marvel related question!',
          'I do not recall!']


def MarvelDex_chat():
    """Adapted from Assignment #2. Basic Chatbot designed to share information about Marvel"""
    
    print("Welcome to the Marvel Index!")
    print("Get to know the Avengers: Ask whose the 'strongest', 'fastest', 'smartest', most 'agile'")
    print("Get a random quote from our heroes: Type the name of any original Avenger followed by 'quote'")
    print("Use keyword 'stones' to learn about the Infinity Gems")
    print("Type 'Inevitable' to end the chat!")
    
    chat = True
    while chat:
        
        # Gets a message from the user
        msg = input('INPUT :\t')
        out_msg = None
        
        # Checks if input is a question
        question = is_question(msg)
        
        # Properly prepares input message
        msg = prepare_text(msg)
        
        # Checks for 'ending' keyword
        if end_chat(msg):
            out_msg = 'SNAP!'
            chat = False
            
        # Checks for keywords we have designed an answer for
        if not out_msg:
            
            # Collects a lists of possible outputs
            outs = []
            
            # Checks for a greeting
            outs.append(chat_response(msg, greetings_in, greetings_out))
            
            # Checks for attribute keyword
            outs.append(att_connect(msg, attribute_in, attribute_out))
            
            # Checks for specific keyword, returns Iron Man quote 
            outs.append(chat_response(msg, iron_man_quote_in, iron_man_quote_out))
            
            # Checks for specific keyword, returns Hulk quote
            outs.append(chat_response(msg, hulk_quote_in, hulk_quote_out))
            
            # Checks for specific keyword, returns Captain America quote
            outs.append(chat_response(msg, captain_america_quote_in, captain_america_quote_out))
            
            # Checks for specific keyword, returns Black Widow quote
            outs.append(chat_response(msg, black_widow_quote_in, black_widow_quote_out))
            
            # Checks for specific keyword, returns Thor quote
            outs.append(chat_response(msg, thor_quote_in, thor_quote_out))
            
            # Checks for specific keyword, returns Hawkeye quote
            outs.append(chat_response(msg, hawkeye_quote_in, hawkeye_quote_out))
            
            # Checks for any heroes not established in the index
            outs.append(special_chat(msg, extra_heroes_in, extra_heroes_out))
            
            # Checks if inputs has words to not be discussed
            outs.append(chat_response(msg, restrict_in, restrict_out))
            
            # None may be appended in some cases, s we won't have a reply
            # Randomly selects an output from the set of outputs that are not None
            options = list(filter(None, outs))
            if options:
                out_msg = random.choice(options)
        
        # Responds to all unprocessed keywords
        if not out_msg:
            if 'stones' in msg:
                out_msg = (report_all_att(infinity_stones))
            else:
                out_msg = random.choice(unknown) 
                 
        print('OUTPUT:', out_msg)